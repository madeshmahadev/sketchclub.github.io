$( document ).ready(function() {

  // Init only once
  $.validateEmail("ev-59c536fffc347087207ec892478424e9");

  // OnClick
  $("#submit").click(function () {
    $("#email").validateEmail(function (response) {
      console.log(response);
    })
  })
});
